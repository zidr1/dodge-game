# Dodge Game — Python & Kivy (Android Ready)

Dodge Game adalah game arcade sederhana di mana pemain harus menghindari musuh yang jatuh dari atas layar.
Versi ini memiliki fitur lengkap: pause/resume, background, suara, highscore saved, dan cocok untuk dibuild ke APK menggunakan Buildozer.

## Cara pakai
1. Install Kivy: `pip install kivy`
2. Jalankan di PC: `python main.py`
3. Untuk build ke Android: gunakan Buildozer (Linux) — `buildozer android debug`

## File penting
- `main.py` — kode utama
- `dodge.kv` — layout Kivy
- `assets/` — tempat gambar dan suara (ganti placeholder dengan aset asli)
- `buildozer.spec` — konfigurasi Buildozer
- `requirements.txt` — dependencies

## Notes
- Aset (PNG/WAV) yang disertakan adalah placeholder. Ganti dengan file gambar dan suara asli sebelum build APK.
- Gyroscope support memerlukan implementasi tambahan di Android; versi ini menyediakan dasar dan memerlukan testing pada device.

## Author
mogaelig / Yazid Rahman
