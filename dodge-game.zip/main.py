from kivy.app import App
from kivy.uix.widget import Widget
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.properties import NumericProperty, StringProperty, BooleanProperty
from kivy.storage.jsonstore import JsonStore
from random import randint, choice
import os

STORE_FILE = 'save.json'

class Player(Widget):
    pass

class Enemy(Widget):
    speed = NumericProperty(200)

class GameWidget(Widget):
    score = NumericProperty(0)
    highscore = NumericProperty(0)
    game_over = BooleanProperty(False)
    paused = BooleanProperty(False)
    bg_music = None

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.enemies = []
        self.spawn_event = None
        self.increase_event = None
        self.load_highscore()
        # load sounds
        self.point_sound = SoundLoader.load(os.path.join('assets','point.wav'))
        self.hit_sound = SoundLoader.load(os.path.join('assets','hit.wav'))
        try:
            self.bg_music = SoundLoader.load(os.path.join('assets','bg_music.wav'))
            if self.bg_music:
                self.bg_music.loop = True
                self.bg_music.volume = 0.5
                self.bg_music.play()
        except Exception:
            pass

    def start(self):
        self.reset()
        # spawn enemy every second (will be adjusted)
        self.spawn_event = Clock.schedule_interval(self.spawn_enemy, 1.0)
        self.increase_event = Clock.schedule_interval(self.increase_difficulty, 5.0)
        Clock.schedule_interval(self.update, 1/60.)

    def reset(self):
        self.score = 0
        self.game_over = False
        self.paused = False
        for e in list(self.enemies):
            if e.parent:
                self.remove_widget(e)
        self.enemies = []
        # create player center bottom
        if not hasattr(self, 'player') or self.player is None:
            from kivy.lang import Builder
            # player added via kv; ensure exists
        # ensure player in widget tree
        self.player.center_x = self.center_x
        self.player.y = 10

    def pause(self):
        self.paused = True
        if self.spawn_event:
            self.spawn_event.cancel()
            self.spawn_event = None
        if self.increase_event:
            self.increase_event.cancel()
            self.increase_event = None
        if self.bg_music:
            self.bg_music.stop()

    def resume(self):
        if not self.paused:
            return
        self.paused = False
        if self.bg_music:
            self.bg_music.play()
        self.spawn_event = Clock.schedule_interval(self.spawn_enemy, 1.0)
        self.increase_event = Clock.schedule_interval(self.increase_difficulty, 5.0)

    def gameover(self):
        self.game_over = True
        if self.hit_sound:
            self.hit_sound.play()
        if self.spawn_event:
            self.spawn_event.cancel()
            self.spawn_event = None
        if self.increase_event:
            self.increase_event.cancel()
            self.increase_event = None
        if self.bg_music:
            self.bg_music.stop()
        self.save_highscore()

    def spawn_enemy(self, dt):
        # create enemy at random x
        from kivy.uix.image import Image
        img = choice(['enemy_red.png','enemy_green.png'])
        e = Enemy(size_hint=(None,None), size=(48,48))
        e_img = Image(source=os.path.join('assets', img), size=e.size, pos=e.pos)
        e.add_widget(e_img)
        e.x = randint(0, max(0, int(self.width - e.width)))
        e.top = self.top + 20
        # speed increases with score
        e.speed = 150 + self.score * 2
        self.add_widget(e)
        self.enemies.append(e)

    def increase_difficulty(self, dt):
        # decrease spawn interval slightly by rescheduling with smaller interval
        if self.spawn_event:
            self.spawn_event.cancel()
        new_interval = max(0.3, 1.0 - (self.score / 200.0))
        self.spawn_event = Clock.schedule_interval(self.spawn_enemy, new_interval)

    def update(self, dt):
        if self.game_over or self.paused:
            return
        # move enemies
        for e in list(self.enemies):
            e.y -= e.speed * dt
            # if enemy passed bottom, increase score
            if e.top < 0:
                self.score += 1
                if self.point_sound:
                    self.point_sound.play()
                try:
                    if e.parent:
                        self.remove_widget(e)
                except Exception:
                    pass
                try:
                    self.enemies.remove(e)
                except ValueError:
                    pass
            else:
                # check collision with player
                if self.player.collide_widget(e):
                    self.gameover()

    def on_touch_move(self, touch):
        if self.game_over or self.paused:
            return
        # move player horizontally with touch
        if touch.x:
            self.player.center_x = touch.x
        return super().on_touch_move(touch)

    def on_size(self, *args):
        # ensure player positioned when resizing
        if hasattr(self, 'player'):
            self.player.center_x = self.center_x
            self.player.y = 10

    def save_highscore(self):
        try:
            store = JsonStore(STORE_FILE)
            prev = store.get('scores')['highscore'] if store.exists('scores') else 0
            if self.score > prev:
                store.put('scores', highscore=self.score)
                self.highscore = self.score
            else:
                self.highscore = prev
        except Exception:
            pass

    def load_highscore(self):
        try:
            store = JsonStore(STORE_FILE)
            if store.exists('scores'):
                self.highscore = store.get('scores')['highscore']
            else:
                self.highscore = 0
        except Exception:
            self.highscore = 0

class DodgeApp(App):
    title = "Dodge Game"

    def build(self):
        game = GameWidget()
        # load kv to add player widget
        from kivy.lang import Builder
        Builder.load_file('dodge.kv')
        root = Builder.load_string("""<Root@GameWidget>:
GameWidget:
    player: player_id
    Label:
        id: hud
""")
        # Actually load the main kv content by filename
        return Builder.load_file('dodge.kv')

    def on_start(self):
        root = self.root
        # schedule start after small delay to ensure widgets ready
        Clock.schedule_once(lambda dt: root.start(), 0.5)

if __name__ == '__main__':
    DodgeApp().run()
